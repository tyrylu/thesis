from .bookmark import Bookmark
from .last_location import LastLocation