sndmgr = None
from .sound_properties import SoundProperties
from .manager import SoundManager