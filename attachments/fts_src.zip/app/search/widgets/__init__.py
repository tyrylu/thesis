from .registry import widget_for, widget_for_column_class
from . import check_box, spin_ctrl, spin_ctrl_double, text_ctrl, choice