class WidgetlessOperator:
    
    @staticmethod
    def get_value_widget(parent, column):
        return None

    @staticmethod
    def get_value_as_string(column, value_widget):
        return ""

    @staticmethod
    def get_value_label(column):
        return ""