import app.main
app.main.main()