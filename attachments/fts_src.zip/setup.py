from setuptools import setup

setup(name="Feel the streets")