pub const TASKS_QUEUE: &str = "tasks";
pub const FUTURE_TASKS_QUEUE: &str = "future_tasks";
pub const DATABASES_UPDATE_HOUR: u32 = 23;
pub const DATABASES_UPDATE_MINUTE: u32 = 57;
pub const DATABASES_UPDATE_SECOND: u32 = 40;
